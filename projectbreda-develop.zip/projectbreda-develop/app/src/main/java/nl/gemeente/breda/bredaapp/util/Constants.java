package nl.gemeente.breda.bredaapp.util;

public class Constants {
	
	public static final String APP_VERSION = "0.1.0";
}
